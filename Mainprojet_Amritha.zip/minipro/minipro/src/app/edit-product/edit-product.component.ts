import { Component, OnInit } from '@angular/core';
import {CalcService} from '../calc.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})



export class EditProductComponent implements OnInit {
// result;
  constructor(private ss:CalcService) { }

  ngOnInit() {

  // this.ss.Add(result67,87){

  }

  }



